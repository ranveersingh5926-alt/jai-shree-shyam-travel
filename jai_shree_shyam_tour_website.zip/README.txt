JAI SHREE SHYAM TOUR & TRAVEL WEBSITE
========================================

Business: Jai Shree Shyam (Nakhat Banna) Tour and Travel Service
Phone/WhatsApp: 8104148505
Location: Jaipur, Rajasthan

Files:
- index.html
- style.css
- script.js

The WhatsApp buttons and enquiry form are already configured for 8104148505.

FREE PUBLISHING WITH GITHUB PAGES:
1. Create/sign in to a free GitHub account.
2. Create a new PUBLIC repository, e.g. jai-shree-shyam-travel.
3. Upload index.html, style.css and script.js to the repository.
4. Go to Settings > Pages.
5. Under Build and deployment, select "Deploy from a branch", choose main and /root, then Save.
6. GitHub will provide your free website address.

A custom .com or .in domain normally costs money, so the free GitHub address is used for ₹0 hosting.
